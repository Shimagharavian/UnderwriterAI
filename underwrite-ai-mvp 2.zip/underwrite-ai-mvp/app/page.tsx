export default function Home() {
  return (
    <main style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
      <h1 style={{ fontSize: "2rem", color: "#0070f3" }}>
        🎉 Welcome to UnderwriterAI!
      </h1>
    </main>
  );
}